<?php
$cabeceraUser = <<<EX
<header>
  <img src="logo.png" alt="logo">
  <h1>Panel de control biblioteca</h1>
  <div>
  <a href="logout.php">
    salir
  </a>
  <a href="gestionPerfil.php">
    <img src="profile.png" alt="profile">
  </a>
  </div>
</header>
<nav>
  <ul>
      <li><a href="index.php">Inicio</a></li>
      <li><a href="buscarLibro.php">Buscar libro</a></li>
  </ul>
</nav>
EX;
