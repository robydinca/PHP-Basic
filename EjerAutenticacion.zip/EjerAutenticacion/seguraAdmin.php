<?php
// Configura para que solo pueda entrar el rol admin
// Verificaremos que hay una sesión válida solamente para el rol de admin
?>
<html>

<body>
Esta página la ves porque te has autenticado en el sistema como admin

<a href="salir.php">Cerrar sesion</a>
</body>

</html>
