<?php
/** Clase para implementar la seguridad de acceso a partes de una AW
 *haremos uso de sesiones php, Credenciales de BD, y Roles de sistema.
 *
 */
  
?>
