<?php
// Configura para que entre todo usuario autenticado
// Verificaremos si hay una sesión válida para cualquier usuario
?>
<html>

<body>
Esta página la ves porque te has autenticado en el sistema

<a href="salir.php">Cerrar sesion</a>
</body>

</html>
