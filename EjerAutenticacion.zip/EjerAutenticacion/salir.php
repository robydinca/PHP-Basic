<?php
// configura para destruir la sesión y volver a la página de inicio
?>
