<?php
//Configuración de los parámetros de Sistema Gestor de Bases de datos

$DB_host ="";
$DB_user ="";
$DB_password ="";
$DB_name ="";
$DB_port="";

?>
