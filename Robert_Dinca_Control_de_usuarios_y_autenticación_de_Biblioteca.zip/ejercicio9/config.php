<?php
define("HOST", "172.21.0.2");
define("USER", "root");
define("PASSWORD", "7227");
define("DB", "biblioteca");
define("PORT", "3306");
?>
